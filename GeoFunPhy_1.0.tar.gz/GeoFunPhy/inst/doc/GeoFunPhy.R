## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, warning=FALSE, message=FALSE--------------------------------------
library(GeoFunPhy)

## ----other setup, warning=FALSE, message=FALSE, echo=FALSE--------------------
library(knitr)
library(DT)
library(rgl)
library(tibble)
options(rgl.useNULL = TRUE)

## ----Create Trait Dataframe, results='asis'-----------------------------------
trait_df <- build_trait_data_LEDA(columns_to_select = c("SLA", "seed_mass", "leaf_mass", "canopy_height"), genera = c("Acer_", "Pinus_", "Fraxinus_", "Quercus_", "Tsuga_", "Solidago_", "Ulmus", "Populus", "Rhododendron_", "Betula_"))


## ----Display Trait Dataframe, echo=FALSE--------------------------------------
DT::datatable(
  trait_df,
  options = list(
    scrollX = TRUE,     # Enable horizontal scrolling
    scrollY = "400px",  # Set the table height with vertical scrolling
    pageLength = 10     # Set the number of rows to display per page
  ),
  width = "100%"
)

## ----Input Phylogeny----------------------------------------------------------
GBMB_phylogeny <- get_phy_angio("GBMB")

## ----Calculate Range Sizes, results=FALSE, echo=TRUE, warning=FALSE, message=FALSE----
species_range_size <- calc_range_size(data_frame = trait_df, min_points = 4, gbif_limit = 2000, num_cores = 1)

## ----Display Range Size Table, echo=FALSE-------------------------------------
DT::datatable(
  species_range_size,
  options = list(
    scrollX = TRUE,     # Enable horizontal scrolling
    scrollY = "400px",  # Set the table height with vertical scrolling
    pageLength = 10     # Set the number of rows to display per page
  ),
  width = "100%"
)

## ----Generate Range Convex Hulls, results=FALSE, echo=TRUE, message=FALSE-----
convex_hulls <- get_range_convex_hulls(data_frame = trait_df, min_points = 4, gbif_limit = 2000, num_cores = 1)

## ----Get Continent SF, results=FALSE, echo=TRUE, message=FALSE----------------
continent_bounds <- get_continent_sf()

## ----Clip Convex Hulls, results=FALSE, echo=TRUE, message=FALSE, warning=FALSE----
clipped_hulls <- clip_polygons_to_land(convex_hulls = convex_hulls, continent_sf = continent_bounds)

## ----Calculate Range Sizes of Clipped Convex Hulls, results=FALSE, echo=TRUE, message=FALSE----
range_sizes_step <- range_sizes(clipped_hulls)

## ----Display Range Size Table Step, echo=FALSE--------------------------------
DT::datatable(
  range_sizes_step,
  options = list(
    scrollX = TRUE,     # Enable horizontal scrolling
    scrollY = "400px",  # Set the table height with vertical scrolling
    pageLength = 10     # Set the number of rows to display per page
  ),
  width = "100%"
)

## ----Find Continents, results=FALSE, echo=TRUE, message=FALSE-----------------
continents <- check_continents(clipped_hulls, continent_bounds)

## ----Display Continent Table, echo=FALSE--------------------------------------
DT::datatable(
  continents,
  options = list(
    scrollX = TRUE,     # Enable horizontal scrolling
    scrollY = "400px",  # Set the table height with vertical scrolling
    pageLength = 10     # Set the number of rows to display per page
  ),
  width = "100%"
)

## ----Find Biomes, results=FALSE, echo=TRUE, message=FALSE---------------------
biomes <- check_biomes(clipped_hulls)

## ----Display Biomes Table, echo=FALSE-----------------------------------------
DT::datatable(
  biomes,
  options = list(
    scrollX = TRUE,     # Enable horizontal scrolling
    scrollY = "400px",  # Set the table height with vertical scrolling
    pageLength = 10     # Set the number of rows to display per page
  ),
  width = "100%"
)

## ----Calculate Evolutionary Distinctiveness, results='asis', message=FALSE, warning=FALSE----
evol_df <- avg_evol_dist(data_frame = trait_df, phy = GBMB_phylogeny, time_slices = c(10, 25, 50), num_cores = 6)
DT::datatable(evol_df)

## ----Display Evolutionary Distinctiveness Table, echo=FALSE-------------------
DT::datatable(
  evol_df,
  options = list(
    scrollX = TRUE,     # Enable horizontal scrolling
    scrollY = "400px",  # Set the table height with vertical scrolling
    pageLength = 10     # Set the number of rows to display per page
  ),
  width = "100%"
)

## ----Remove NA, results='asis'------------------------------------------------

merged_df <- merge(merge(trait_df, species_range_size, by = "species_name", all = TRUE), evol_df, by = "species_name", all = TRUE)

merged_df <- na.omit(merged_df)

## ----Calculate Functional Distinctiveness, results='asis'---------------------
fun_evol_range_df <- fun_dist(data_frame = merged_df, trait_columns = c("SLA", "seed_mass", "leaf_mass", "canopy_height"))

## ----Display Functional Distinctiveness Table, echo=FALSE---------------------
DT::datatable(
  fun_evol_range_df,
  options = list(
    scrollX = TRUE,     # Enable horizontal scrolling
    scrollY = "400px",  # Set the table height with vertical scrolling
    pageLength = 10     # Set the number of rows to display per page
  ),
  width = "100%"
)

## ----Z Transform Dataframe, results='asis'------------------------------------
z_score_df <- scale_by_median(data_frame = fun_evol_range_df, columns_chosen = c("range_size", "mean_evol_dist"))

## ----Display Scaled Data Table, echo=FALSE------------------------------------
DT::datatable(
  z_score_df,
  options = list(
    scrollX = TRUE,     # Enable horizontal scrolling
    scrollY = "400px",  # Set the table height with vertical scrolling
    pageLength = 10     # Set the number of rows to display per page
  ),
  width = "100%"
)

## ----Elbow Plot Range Size, fig.width = 8, fig.height = 6---------------------
range_elbow <- elbow_plot(data = z_score_df, variable = "range_size", k_max = 5, ggplot = TRUE)

print(range_elbow)

## ----Elbow Plot Evolutionary Distinctiveness, fig.width = 8, fig.height = 6----
evol_elbow <- elbow_plot(data = z_score_df, variable = "mean_evol_dist", k_max = 5, ggplot = TRUE)

print(evol_elbow)

## ----Elbow Plot Functional Distinctiveness, fig.width = 8, fig.height = 6-----
fun_elbow <- elbow_plot(data = z_score_df, variable = "fun_dist", k_max = 5, ggplot = TRUE)

print(fun_elbow)

## ----Check EER Status, results=FALSE, echo=TRUE, message=FALSE----------------
EER_stat_df <- check_EER_status_k(data_frame = z_score_df, range_size_col = "range_size", mean_evol_dist_col = "mean_evol_dist", fun_dist_col = "fun_dist", range_size_k = 3, mean_evol_dist_k = 2, fun_dist_k = 2)

## ----Display EER Status Table, echo=FALSE-------------------------------------
DT::datatable(
  EER_stat_df,
  options = list(
    scrollX = TRUE,     # Enable horizontal scrolling
    scrollY = "400px",  # Set the table height with vertical scrolling
    pageLength = 10     # Set the number of rows to display per page
  ),
  width = "100%"
)

## ----Create 3d Visualization, out.width="100%", fig.dim = c(6, 6)-------------
figure <- plot_EER_status(data_frame = EER_stat_df, fun_dist = "fun_dist", range_size = "range_size", evol_dist = "mean_evol_dist")
rglwidget()

## ----Plot Convex Hulls, results=FALSE, echo=TRUE, message=FALSE---------------
trait_df_subset <- trait_df[1:5, ]
acer_maps <- range_poly_map(data_frame = trait_df_subset, clip = TRUE, continent_sf = continent_bounds)

## ----Map Output, out.width='800px', out.height='600px'------------------------
knitr::include_graphics("acer_map_screenshot.png")

